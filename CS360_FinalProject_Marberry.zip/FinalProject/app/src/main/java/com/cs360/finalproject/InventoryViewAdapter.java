package com.cs360.finalproject;

import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cs360.finalproject.data.DatabaseAPI;
import com.cs360.finalproject.data.model.InventoryItem;

import java.lang.ref.WeakReference;
import java.util.List;


/**
 * Adapter for InventoryView's RecyclerView
 */
public class InventoryViewAdapter extends RecyclerView.Adapter<InventoryViewAdapter.ViewHolder> {

    // Reference to InventoryActivity
    private final WeakReference<InventoryActivity> mInventoryRef;

    private final DatabaseAPI mDatabase;
    private final List<InventoryItem> localDataSet;

    // Custom ViewHolder to define list items
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final GridLayout inventoryItemRow;
        public TextWatcher quantityWatcher;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            inventoryItemRow = (GridLayout) itemView.findViewById(R.id.inventory_item_row);
        }

        public GridLayout getInventoryItemRow() {
            return this.inventoryItemRow;
        }
    }


    public InventoryViewAdapter(InventoryActivity context, List<InventoryItem> dataSet) {
        localDataSet = dataSet;
        mInventoryRef = new WeakReference<>(context);
        mDatabase = DatabaseAPI.getInstance(context);
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {

        // Creating a view for the list item
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.inventory_item_row, viewGroup, false);

        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {

        // Getting local data
        final InventoryItem inventoryItem = localDataSet.get(position);
        final String itemName = mDatabase.getItem( inventoryItem.getItemId() ).getName();

        // Getting views from viewHolder
        GridLayout row              = viewHolder.getInventoryItemRow();
        TextView nameView           = row.findViewById(R.id.name_label);
        EditText quantityView       = row.findViewById(R.id.quantity_entry);
        ImageButton deleteButton    = row.findViewById(R.id.delete_button);

        // Removing old TextWatcher before setting quantity text
        if (viewHolder.quantityWatcher != null) {
            quantityView.removeTextChangedListener(viewHolder.quantityWatcher);
        }

        // Changing values to match new inventoryItem
        nameView.setText(itemName);
        quantityView.setText( String.valueOf(inventoryItem.getItemQuantity()) );

        // Configuring listeners
        final InventoryActivity inventoryActivity = mInventoryRef.get();

        // Adding new TextWatcher
        viewHolder.quantityWatcher = inventoryActivity.getQuantityTextWatcher(quantityView, inventoryItem);

        quantityView.addTextChangedListener(viewHolder.quantityWatcher);
        deleteButton.setOnClickListener( v -> inventoryActivity.removeItem(inventoryItem) );
    }


    @Override
    public int getItemCount() {
        return localDataSet.size();
    }
}
