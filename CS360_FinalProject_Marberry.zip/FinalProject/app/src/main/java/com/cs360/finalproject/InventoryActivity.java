package com.cs360.finalproject;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cs360.finalproject.data.DatabaseAPI;
import com.cs360.finalproject.data.model.User;
import com.cs360.finalproject.data.model.Item;
import com.cs360.finalproject.data.model.InventoryItem;

import java.util.List;


/**
 * Activity to display a User's inventory.
 */
public class InventoryActivity extends AppCompatActivity {

    // Tag for log
    public static String TAG = "InventoryActivity";

    // Custom request code
    public static int REQUEST_SMS_SEND_PERMISSIONS = 1;

    // Permissions needed to send SMS
    public static final String[] REQUIRED_PERMISSIONS = new String[] {
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_SMS
    };

    // Widgets
    private RecyclerView mRecyclerView;
    //    private GridLayout mGrid;
    private TextView mInventoryTitle;
    private TextView mNameHeader;
    private TextView mQuantityHeader;
    private ConstraintLayout mEmptyInventoryDisplay;

    // Data
    private DatabaseAPI mDatabase;
    private User mCurrentUser;
    private List<InventoryItem> mUserInventory;

    // Handles receiving new Item information from NewItemActivity
    private final ActivityResultLauncher<Intent> mNewItemResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() != InventoryActivity.RESULT_OK) {
                    return;
                }

                // Getting data
                Intent data = result.getData();
                if (data == null) {
                    Log.e(TAG, "Error parsing NewItemActivity return");
                    return;
                }

                final String name = data.getStringExtra(NewItemActivity.EXTRA_NAME);
                if (name == null) {
                    Log.e(TAG, "Error parsing NewItemActivity return: Name is null");
                    return;
                }

                final int quantity = data.getIntExtra(NewItemActivity.EXTRA_QUANTITY, 0);
                final Item newItem = new Item(name);

                // Adding new Item
                AddNewItem(newItem, quantity);
            }
    );


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Getting the current user
        Intent intent = getIntent();
        long userId = intent.getLongExtra(getString(R.string.user_id_key), -1);

        // Returns to Login screen if there's an error getting the current user
        if (userId == -1) {
            Toast.makeText(
                    this,
                    "There was an error loading the user's account",
                    Toast.LENGTH_SHORT
            )
            .show();

            intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        }

        mDatabase = DatabaseAPI.getInstance(this);

        // Getting a User object from database
        mCurrentUser = mDatabase.getUser(userId);
        if (mCurrentUser == null) {
            Toast.makeText(this, getString(R.string.user_load_error), Toast.LENGTH_SHORT)
                .show();
            return;
        }

        // Loading widgets
        mRecyclerView = findViewById(R.id.recycler);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mInventoryTitle = findViewById(R.id.inventory_title);
        mNameHeader = findViewById(R.id.name_header);
        mQuantityHeader = findViewById(R.id.quantity_header);
        mEmptyInventoryDisplay = findViewById(R.id.empty_inventory_display);

        // Loads User's inventory
        refreshInventoryGrid();
    }


    @Override
    protected void onStop() {
        super.onStop();

        // Updates the quantities if InventoryItem rows
        for (InventoryItem inventoryItem: mUserInventory) {
            mDatabase.updateInventoryItem(inventoryItem);
        }
    }


    /**
     * Callback for new item FAB which launches a NewItemActivity
     *
     * @param view Button View
     */
    public void onNewItemButtonPressed(View view) {
        Intent intent = new Intent(this, NewItemActivity.class);
        mNewItemResultLauncher.launch(intent);
    }


    /**
     * Removes an item from the user's inventory and refreshed the grid.
     * @param inventoryItem InventoryItem to remove
     */
    public void removeItem(InventoryItem inventoryItem) {
        assert mUserInventory != null && mUserInventory.contains(inventoryItem);
        mDatabase.deleteInventoryItem(inventoryItem);
        refreshInventoryGrid();
    }


    /**
     * Checks a list of permissions
     *
     * @param permissions List of Manifest.permission constants
     * @return True if every input permission has been granted
     */
    public boolean hasPermissions(String[] permissions) {
        int permission;

        // Returns false if any permission is missing
        for (String p : permissions) {
            permission = checkSelfPermission(p);
            if (permission != PackageManager.PERMISSION_GRANTED) return false;
        }

        return true;
    }


    /**
     * Requests required permissions for sending SMS notifications.
     */
    public void requestPermissions() {

        // Showing an explanation
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View layout = getLayoutInflater().inflate(R.layout.sms_request_alert, null);
        builder.setView(layout);

        final AlertDialog dialog = builder.create();

        // Granting permission
        ImageButton positiveButton = layout.findViewById(R.id.positive_button);
        positiveButton.setOnClickListener(
                v -> {
                    requestPermissions(REQUIRED_PERMISSIONS, REQUEST_SMS_SEND_PERMISSIONS);
                    dialog.dismiss();
                }
        );

        // Denying permission
        ImageButton negativeButton = layout.findViewById(R.id.negative_button);
        negativeButton.setOnClickListener(
                v -> dialog.dismiss()
        );

        dialog.show();
    }


    /**
     * Sends the user a text message saying an item is out of stock
     *
     * @param itemName Item name
     */
    public void outOfStockNotification(@NonNull String itemName) {

        // Requesting permissions
        if ( !hasPermissions(REQUIRED_PERMISSIONS) ) {
            requestPermissions();

            // Recursive call will send the SMS notification
            // when the user gives the permission
            if (hasPermissions(REQUIRED_PERMISSIONS)) outOfStockNotification(itemName);

            return;
        }

        // Getting the user's phone number
        final TelephonyManager tmManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        final String userPhoneNumber;

        try {
            userPhoneNumber = tmManager.getLine1Number();
        }

        catch (SecurityException e) {
            Log.e(TAG, "Telephony Error: Permissions flagged as granted yet a SecurityException occured: " + e.toString());
            return;
        }

        // Thrown when device doesn't have Telephony
        catch (UnsupportedOperationException e) {
            Toast.makeText(
                    this,
                    "This device doesn't support sending SMS notifications",
                    Toast.LENGTH_SHORT
            )
            .show();
            return;
        }

        // Sending the text message
        final String message = getString(
                R.string.out_of_stock_notification,
                getString(R.string.app_name),
                itemName
        );

        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(userPhoneNumber, null, message, null, null);
    }


    /**
     * Returns a TextWatcher for an InventoryItem's quantity EditText. This is used
     * by the RecyclerView adapter to update its ViewHolders.
     *
     * @param quantityView EditText for Item quantity
     * @param inventoryItem InventoryItem pertaining to the quantityView
     * @return A new TextWatcher
     */
    public TextWatcher getQuantityTextWatcher(EditText quantityView, InventoryItem inventoryItem) {
        return new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                final String input = s.toString();

                // Defaults to 0 when text is left empty
                if (input.isEmpty()) {
                    quantityView.setText("0");
                    inventoryItem.setItemQuantity(0);
                    return;
                }

                int val = Integer.parseInt(input);

                // SMS notification when an Item is out of stock
                final Item item = mDatabase.getItem(inventoryItem.getItemId());
                if (val == 0) outOfStockNotification(item.getName());

                // Updating InventoryItem object. The actual database
                // update doesn't happen until the activity is stopped.
                inventoryItem.setItemQuantity(val);
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }
        };
    }


    /**
     * Used to refresh inventory grid after the database is modified.
     */
    private void refreshInventoryGrid() {
        assert mCurrentUser != null;

        // Clearing widgets first
        if (mRecyclerView.getChildCount() > 0) {
            mRecyclerView.removeAllViews();
        }

        // Reloading user's inventory
        mUserInventory = mDatabase.getUserInventoryItems(mCurrentUser.getId());

        // Special display for empty inventory
        if (mUserInventory.isEmpty()) {
            setEmptyInventoryDisplay(true);
            return;
        }

        setEmptyInventoryDisplay(false);

        // Configuring RecyclerView
        InventoryViewAdapter mRecyclerAdapter = new InventoryViewAdapter(this, mUserInventory);
        mRecyclerView.setAdapter(mRecyclerAdapter);
    }


    /**
     * Toggles the display for when a user's inventory is empty
     * @param on Boolean for on/off state
     */
    private void setEmptyInventoryDisplay(boolean on) {

        // Enabling display
        if (on) {
            mRecyclerView.setVisibility(View.GONE);
            mInventoryTitle.setVisibility(View.GONE);
            mNameHeader.setVisibility(View.GONE);
            mQuantityHeader.setVisibility(View.GONE);

            mEmptyInventoryDisplay.setVisibility(View.VISIBLE);
        }

        // Disabling display
        else {
            mRecyclerView.setVisibility(View.VISIBLE);
            mInventoryTitle.setVisibility(View.VISIBLE);
            mNameHeader.setVisibility(View.VISIBLE);
            mQuantityHeader.setVisibility(View.VISIBLE);

            mEmptyInventoryDisplay.setVisibility(View.GONE);
        }
    }


    /**
     * Adds an Item to the user's inventory. If this Item is unique, not in the database,
     * this will create a new row in the Items table. Otherwise, if the user doesn't already
     * have it in their inventory, it will add a row to the InventoryItems table.
     *
     * @param item Item Entity
     * @param quantity Quantity of the new Item
     */
    private void AddNewItem(@NonNull Item item, Integer quantity) {
        final long userId = mCurrentUser.getId();

        // This prevents duplicate (same name) Items
        Item workingItem = mDatabase.getItem(item.getName());

        // Adding Item to database
        if (workingItem == null) {
            mDatabase.addItem(item);
            workingItem = item;
        }

        final long itemId = workingItem.getId();
        InventoryItem inventoryItem = mDatabase.getInventoryItem(userId, itemId);

        // Verifying the User's inventory doesn't already have this item
        if (inventoryItem != null) {
            Toast.makeText(
                this,
                getString(R.string.duplicate_item_warning, workingItem.getName()),
                Toast.LENGTH_SHORT
            )
            .show();

            return;
        }

        // Adding new InventoryItem
        inventoryItem = new InventoryItem(userId, itemId, quantity);
        mDatabase.addInventoryItem(inventoryItem);

        refreshInventoryGrid();
    }
}