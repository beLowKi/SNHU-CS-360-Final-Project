package com.cs360.finalproject.data.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Item {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long mId;

    @NonNull
    @ColumnInfo(name = "name")
    private String mName;


    public Item() {
        this.mName = "n/a";
    }

    public Item(@NonNull String name) {
        this.mName = name;
    }

    public long getId() {
        return mId;
    }

    public void setId(long itemId) {
        this.mId = itemId;
    }

    @NonNull
    public String getName() {
        return mName;
    }

    public void setName(@NonNull String name) {
        this.mName = name;
    }
}
