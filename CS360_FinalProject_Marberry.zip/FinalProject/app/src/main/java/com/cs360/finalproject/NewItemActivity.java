package com.cs360.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

import java.util.Objects;


/**
 * Activity which acts as a form for a new item in a user's inventory.
 */
public class NewItemActivity extends AppCompatActivity {

    // Names for Intent extras
    public static final String EXTRA_NAME = "newItemName";
    public static final String EXTRA_QUANTITY = "newItemQuantity";

    // Widgets
    private TextInputEditText mQuantityView;
    private TextInputEditText mNameView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_new_item);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mQuantityView = findViewById(R.id.item_quantity_entry);
        mNameView = findViewById(R.id.item_name_entry);
    }


    /**
     * Attempts to end the activity--allowing the input name and quantity to be received
     * by the previous Activity.
     *
     * @param view Button View
     */
    public void SubmitNewItem(View view) {
        final String name = Objects.requireNonNull(mNameView.getText()).toString();
        final String inputQuantity = Objects.requireNonNull(mQuantityView.getText()).toString();
        int quantity = -1;

        // Error if either entry is empty
        if (name.isEmpty() || inputQuantity.isEmpty()) {

            // Name
            if (name.isEmpty()) mNameView.setError("Item name is required");

            // Quantity
            if (inputQuantity.isEmpty()) mQuantityView.setError("Item quantity is required");

            return;
        }

        try {
            quantity = Integer.parseInt(inputQuantity);
        }

        // Triggers when the input number is greater than the integer limit
        catch (NumberFormatException e) {
            mQuantityView.setError("Quantity is too large");
            return;
        }

        // The entry prevents '-' from being input, so a negative 'val'
        // is likely due to integer overflow
        if (quantity < 0) {
            mQuantityView.setError("Quantity is too large");
            return;
        }

        // Sending new Item information to previous activity
        Intent intent = new Intent();
        intent.putExtra(EXTRA_NAME, name);
        intent.putExtra(EXTRA_QUANTITY, quantity);
        setResult(RESULT_OK, intent);

        finish();
    }
}