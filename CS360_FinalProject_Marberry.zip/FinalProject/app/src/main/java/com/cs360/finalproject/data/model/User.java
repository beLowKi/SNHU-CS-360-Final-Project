package com.cs360.finalproject.data.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class User {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long mId;

    @NonNull
    @ColumnInfo(name = "username")
    private String mUsername;


    @NonNull
    @ColumnInfo(name = "password")
    private String mPassword;


    public User() {
        this.mUsername = "";
        this.mPassword = "";
    }

    public User(@NonNull String username, @NonNull String password) {
        this.mUsername = username;
        this.mPassword = password;
    }

    public long getId() {
        return mId;
    }

    public void setId(long userId) {
        this.mId = userId;
    }

    @NonNull
    public String getUsername() {
        return mUsername;
    }

    public void setUsername(@NonNull String username) {
        this.mUsername = username;
    }

    @NonNull
    public String getPassword() {
        return mPassword;
    }

    public void setPassword(@NonNull String password) {
        this.mPassword = password;
    }
}
