package com.cs360.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.cs360.finalproject.data.DatabaseAPI;
import com.cs360.finalproject.data.model.User;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Objects;


/**
 * Startup Activity for users to create and sign in to their accounts.
 */
public class LoginActivity extends AppCompatActivity {
    private DatabaseAPI mDatabase;
    private TextInputEditText mUsernameEntry;
    private TextInputEditText mPasswordEntry;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mDatabase = DatabaseAPI.getInstance(getApplicationContext());
        mUsernameEntry = findViewById(R.id.username_entry);
        mPasswordEntry = findViewById(R.id.password_entry);
    }


    /**
     * Attempts to log in to a User account with the input username and password
     *
     * @param view Button View
     */
    public void login(View view) {

        // Getting input
        final String inputUsername = Objects.requireNonNull(mUsernameEntry.getText()).toString();
        final String inputPassword = Objects.requireNonNull(mPasswordEntry.getText()).toString();

        // Special messages when either entry is empty
        if (checkInputsEmpty(inputUsername, inputPassword)) return;

        // Checks the database for a matching account
        // NOTE rather than saying which input is incorrect, for security
        // reasons, I think just saying that either/or was wrong is safer.
        final User userAcc = mDatabase.getUser(inputUsername, inputPassword);
        if (userAcc == null) {
            String message = getString(R.string.account_not_found);

            // Shows error on each entry
            mUsernameEntry.setError(message);
            mPasswordEntry.setError(message);

            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            return;
        }

        // Switching to inventory activity
        moveToInventoryScreen(userAcc.getId());
    }


    /**
     * Attempts to create a new User from the input username and password
     *
     * @param view Button View
     */
    public void signUp(View view) {

        // Getting inputs
        final String inputUsername = Objects.requireNonNull(mUsernameEntry.getText()).toString();
        final String inputPassword = Objects.requireNonNull(mPasswordEntry.getText()).toString();

        // Special messages when either entry is empty
        if (checkInputsEmpty(inputUsername, inputPassword)) return;

        // Verifying a User with the given username doesn't exist
        if (mDatabase.userExists(inputUsername)) {
            String message = getString(R.string.username_is_taken, inputUsername);
            mUsernameEntry.setError(message);
//            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            return;
        }

        // Creating new account
        final User newUser = new User(inputUsername, inputPassword);
        mDatabase.addUser(newUser);

        // Success notification
        Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();

        // Signing in
        moveToInventoryScreen(newUser.getId());
    }


    /**
     * Begins the InventoryActivity with the input User's id.
     *
     * @param userId User id
     */
    public void moveToInventoryScreen(long userId) {
        Intent intent = new Intent(this, InventoryActivity.class);

        // Passes the current user's id to the next activity
        intent.putExtra(getString(R.string.user_id_key), userId);
        startActivity(intent);
    }

    
    // Checks username and password input. Displays error and returns true if either input is empty
    private boolean checkInputsEmpty(String username, String password) {
        if (!(username.isEmpty() || password.isEmpty())) return false;

        // Blank username
        if (username.isEmpty())  mUsernameEntry.setError("Username is required");

        // Blank password
        if (password.isEmpty()) mPasswordEntry.setError("Password is required");

        return true;
    }
}