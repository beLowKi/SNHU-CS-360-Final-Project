package com.cs360.finalproject.data;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.cs360.finalproject.data.dao.InventoryItemDao;
import com.cs360.finalproject.data.dao.ItemDao;
import com.cs360.finalproject.data.dao.UserDao;
import com.cs360.finalproject.data.model.InventoryItem;
import com.cs360.finalproject.data.model.Item;
import com.cs360.finalproject.data.model.User;

@Database( version = 1, entities = { User.class, Item.class, InventoryItem.class } )
public abstract class InventoryManagerDB extends RoomDatabase {

    public abstract UserDao userDao();
    public abstract ItemDao itemDao();
    public abstract InventoryItemDao inventoryItemDao();
}
