package com.cs360.finalproject.data.dao;

import androidx.annotation.NonNull;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.cs360.finalproject.data.model.Item;

@Dao
public interface ItemDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addItem(Item item);

    @Query("SELECT * FROM Item WHERE id = :id")
    Item getItem(long id);

    @Query("SELECT * FROM Item WHERE name = :name")
    Item getItem(@NonNull String name);

    @Update
    void updateItem(Item item);

    @Delete
    void deleteItem(Item item);
}
