package com.cs360.finalproject.data.dao;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.cs360.finalproject.data.model.Item;
import com.cs360.finalproject.data.model.User;

import java.util.List;

@Dao
public interface UserDao {

    @Insert
    long addUser(User user);

    @Query("SELECT * FROM User WHERE id = :id")
    User getUser(long id);

    @Query("SELECT * FROM User WHERE username = :username AND password = :password")
    User getUser(@NonNull String username, @NonNull String password);

    @Query("SELECT * FROM User WHERE username = :username")
    List<User> getUsers(@NonNull String username);

    /**
     * Returns all unique Items in a User's inventory. These do NOT, however, include
     * quantity--only information about the Item. To reference Item quantity, see InventoryItem
     * and 'getUserInventoryItems'.
     *
     * @param userId User id
     */
    @Query(
            "SELECT * FROM Item " +
                    "INNER JOIN InventoryItem ON Item.id = InventoryItem.item_id " +
                    "WHERE InventoryItem.user_id = :userId "
    )
    List<Item> getUserItems(long userId);

    @Update
    void updateUser(User user);

    @Delete
    void deleteUser(User user);
}
