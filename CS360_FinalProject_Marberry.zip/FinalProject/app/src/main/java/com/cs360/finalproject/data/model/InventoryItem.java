package com.cs360.finalproject.data.model;

import static androidx.room.ForeignKey.CASCADE;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;


/**
 * A class/table which shows which Items are in which User's inventory.
 * Each instance/row represents a unique Item in the inventory of the associated User.
 */
@Entity(
        primaryKeys = {"user_id", "item_id"},
        foreignKeys = {

                // User
                @ForeignKey(
                        entity = User.class,
                        parentColumns = "id",
                        childColumns = "user_id",
                        onDelete = CASCADE
                ),

                // Item
                @ForeignKey(
                        entity = Item.class,
                        parentColumns = "id",
                        childColumns = "item_id",
                        onDelete = CASCADE
                )
        }
)
public class InventoryItem {

    @ColumnInfo(name = "user_id")
    private long mUserId;

    @ColumnInfo(name = "item_id")
    private long mItemId;

    @NonNull
    @ColumnInfo(name = "item_quantity")
    private Integer mItemQuantity;


    public InventoryItem() {
        this.mUserId = -1;
        this.mItemId = -1;
        this.mItemQuantity = -1;
    }

    public InventoryItem(long userId, long itemId, @NonNull Integer quantity) {
        this.mUserId = userId;
        this.mItemId = itemId;
        this.mItemQuantity = quantity;
    }

    public long getUserId() {
        return mUserId;
    }

    public void setUserId(long userId) {
        this.mUserId = userId;
    }

    public long getItemId() {
        return mItemId;
    }

    public void setItemId(long itemId) {
        this.mItemId = itemId;
    }

    public Integer getItemQuantity() {
        return mItemQuantity;
    }

    @NonNull
    public void setItemQuantity(Integer number) {
        assert(number >= 0);
        this.mItemQuantity = number;
    }
}
