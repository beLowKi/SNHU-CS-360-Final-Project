package com.cs360.finalproject.data;


import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.room.Room;

import com.cs360.finalproject.data.dao.InventoryItemDao;
import com.cs360.finalproject.data.dao.ItemDao;
import com.cs360.finalproject.data.dao.UserDao;
import com.cs360.finalproject.data.model.InventoryItem;
import com.cs360.finalproject.data.model.Item;
import com.cs360.finalproject.data.model.User;

import java.util.List;

/**
 * Singleton class for accessing and managing the Inventory Manager database.
 */
public class DatabaseAPI {

    private static DatabaseAPI instance;
    private final UserDao mUserDao;
    private final ItemDao mItemDao;
    private final InventoryItemDao mInventoryItemDao;


    /**
     * Returns the singleton instance
     * @param context App context
     */
    public static DatabaseAPI getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseAPI(context);
        }
        return instance;
    }


    private DatabaseAPI(Context context) {

        // Building the database
        InventoryManagerDB database = Room.databaseBuilder(context, InventoryManagerDB.class, "inventory_manager.db")
           .allowMainThreadQueries()
           .build();

        // Getting the Dao
        mUserDao = database.userDao();
        mItemDao = database.itemDao();
        mInventoryItemDao = database.inventoryItemDao();
    }


    // CRUD FUNCTIONALITY

    // Create

    public void addUser(User user) {
        long userId = mUserDao.addUser(user);
        user.setId(userId);
    }

    public void addItem(Item item) {
        long itemId = mItemDao.addItem(item);
        item.setId(itemId);
    }

    public void addInventoryItem(InventoryItem inventoryItem) {
        mInventoryItemDao.addInventoryItem(inventoryItem);
    }


    // Read

    public User getUser(long userId) {
        return mUserDao.getUser(userId);
    }

    public User getUser(String username, String password) {
        return mUserDao.getUser(username, password);
    }

    public boolean userExists(String username) {
        List<User> matchingUsers = mUserDao.getUsers(username);
        return !matchingUsers.isEmpty();
    }

    public Item getItem(long itemId) {
        return mItemDao.getItem(itemId);
    }

    public Item getItem(String itemName) {
        return mItemDao.getItem(itemName);
    }

    public InventoryItem getInventoryItem(long userId, long itemId) {
        return mInventoryItemDao.getInventoryItem(userId, itemId);
    }

    public List<InventoryItem> getUserInventoryItems(long userId) {
        return mInventoryItemDao.getUserInventoryItems(userId);
    }


    // Update

    public void updateUser(User user) {
        mUserDao.updateUser(user);
    }

    public void updateItem(Item item) {
        mItemDao.updateItem(item);
    }

    public void updateInventoryItem(InventoryItem inventoryItem) {
        mInventoryItemDao.updateInventoryItem(inventoryItem);
    }


    // Delete

    public void deleteUser(User user) {
        mUserDao.deleteUser(user);
    }

    public void deleteItem(Item item) {
        mItemDao.deleteItem(item);
    }

    public void deleteInventoryItem(InventoryItem inventoryItem) {
        mInventoryItemDao.deleteInventoryItem(inventoryItem);
    }
}
