package com.cs360.finalproject.data.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.cs360.finalproject.data.model.InventoryItem;

import java.util.List;

@Dao
public interface InventoryItemDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addInventoryItem(InventoryItem inventoryItem);

    @Query("SELECT * FROM InventoryItem WHERE user_id = :userId AND item_id = :itemId")
    InventoryItem getInventoryItem(long userId, long itemId);


    /**
     * Returns all InventoryItems that reference the input User. To get Item objects,
     * see 'getUserItems'.
     *
     * @param userId User id
     */
    @Query("SELECT * FROM InventoryItem WHERE user_id = :userId")
    List<InventoryItem> getUserInventoryItems(long userId);

    @Update
    void updateInventoryItem(InventoryItem inventoryItem);

    @Delete
    void deleteInventoryItem(InventoryItem inventoryItem);

}
